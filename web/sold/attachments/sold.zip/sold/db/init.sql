CREATE TABLE users(
    id SERIAL PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    pw VARCHAR(255) NOT NULL,
    balance FLOAT NOT NULL
);

CREATE TABLE items(
    id SERIAL PRIMARY KEY,
    itemname VARCHAR(255) NOT NULL UNIQUE,
    price FLOAT NOT NULL,
    availabilility INT NOT NULL,
    maxdiscount FLOAT NOT NULL
);

CREATE TABLE coupons(
    id SERIAL PRIMARY KEY,
    couponname VARCHAR(255) NOT NULL UNIQUE,
    discount FLOAT NOT NULL
);

INSERT INTO items(itemname, price, availabilility, maxdiscount) VALUES
    ('Capuccino', 7, 3, 0.5), ('Espresso', 1.3, 5, 0.5), ('Macha Tea', 6, 2, 1.5), 
    ('Green Tea', 4, 1, 1.5), ('Black Tea', 4, 1, 1.5), ('Ginger Tea', 5, 2, 1.5), ('Flag Tea', 1337, 0, 0);

INSERT INTO coupons(couponname, discount) VALUES ('FREE5', 5);