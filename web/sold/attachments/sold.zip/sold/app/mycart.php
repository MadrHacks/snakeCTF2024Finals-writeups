<?php
include_once("utils/common.php");
$visitor = get_visitor();
$won = ($visitor === 1.0);

if (!logged_in()) {
    header("Content-Type: application/json");
    header("Location: /index.php");
    echo '{"message": "Log in to access the website!"}';
    exit(0);
}
if ($won) {
    // Extra prize for the luckiest
    function gEt_FlAg()
    {
        echo getenv("FLAG");
    }
}
?>
<html>

<head>
    <title>Cart</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        madrhacks: "#00755c",
                    }
                }
            }
        }
    </script>
</head>

<body class="flex items-center justify-center">
    <div class="rounded-lg py-6 px-10 bg-white/10 shadow-lg max-w-xl w-full">
        <?php
        $user = query_user(logged_user());
        $cart = get_cart();
        $items = $cart->get_objects();
        ?>
        <h1 class="text-2xl font-bold">Your cart</h1>
        <p>You have a balance of <?= $user->get_balance() ?>&euro;.</p>

        <div
            class="rounded-lg px-4 py-2 my-4 <?= ($won ? "bg-green-500/20 border border-green-500/50" : "bg-yellow-500/20 border border-yellow-500/50") ?>">
            <p> You are our <?= $visitor ?>th visitor.
                <?= ($won ? "🎉 You won!<br/>Apply the code <b>FREE5</b> for a discount." : "😢 You didn't win.<br/>Come back again for a prize.") ?>
            </p>
        </div>

        <div class="rounded-lg px-4 py-2 my-4 bg-white/5 border border-white/20">
            <? if (!$cart->has_coupon()) { ?>
                <p class="text-lg"> Apply a coupon code</p>

                <div class="flex mt-2">
                    <input id='coupon' name='coupon' type='text' placeholder="COUPON10"
                        class="placeholder:text-white/50 py-1 px-4 w-full bg-white/5 rounded-l-lg shadow-lg" />
                    <button
                        onclick='document.location=`/api/apply.php?req=discount&action=add&coupon=${window.coupon.value}`'
                        class="text-center py-1 my-auto px-4 bg-madrhacks rounded-r-lg shadow-lg">
                        Apply
                    </button>
                </div>
            <? } else { ?>
                <p>The coupon <b><?= $cart->get_coupon()->print(false) ?></b> has been applied</p>
                <button onclick='document.location=`/api/apply.php?req=discount&action=remove`'
                    class="text-center py-1 my-auto px-4 bg-madrhacks rounded-lg shadow-lg mt-2">
                    Remove the coupon
                </button>
            <? } ?>
        </div>

        <div class="flex flex-col gap-y-4 w-full mt-4">
            <? foreach ($items as $item => $data) { ?>
                <div class="flex rounded-lg shadow-lg bg-white/5 border border-white/20 px-4 py-2 justify-between">
                    <div>
                        <p class="text-lg"><?= $item ?></p>
                        <p class="text-sm opacity-75">
                            <?= $data["price"] ?>&euro;
                            (<?= $data["quantity"] ?> quantity)
                        </p>
                    </div>
                    <button onclick='document.location="api/apply.php?req=remove&item=<?= $item ?>"'
                        value='Remove from cart' class="text-center py-1 my-auto px-4 bg-madrhacks rounded-lg shadow-lg">
                        Remove from cart
                    </button>
                </div>
            <? } ?>
        </div>

        <p class="mt-4 text-center text-lg">Your total is: <?= $cart->compute_total() ?>&euro;</p>
    </div>
</body>

</html>