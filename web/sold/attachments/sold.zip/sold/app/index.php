<?php
include_once("utils/common.php");
?>
<html>

<head>
    <title>Drugstore 2.0</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        madrhacks: "#00755c",
                    }
                }
            }
        }
    </script>
</head>

<body class="flex items-center justify-center">
    <?php
    if (!logged_in()) { ?>
        <div class="rounded-lg py-6 px-10 bg-white/10 shadow-lg max-w-xl w-full">
            <h1 class="text-2xl font-bold">Welcome!</h1>
            <p>Create an account or login to start shopping.</p>

            <div class="flex gap-x-4 w-full mt-4">
                <a href="/login.php" class="text-center py-2 px-4 flex-grow bg-madrhacks rounded-lg shadow-lg">
                    Login
                </a>
                <a href="/register.php" class="text-center py-2 px-4 flex-grow bg-madrhacks rounded-lg shadow-lg">
                    Register
                </a>
            </div>
        </div>
        <?php
    } else {
        $user = query_user(logged_user());
        $items = query_items(); ?>

        <div class="rounded-lg py-6 px-10 bg-white/10 shadow-lg max-w-xl w-full">
            <h1 class="text-2xl font-bold">Welcome <?= logged_user() ?>!</h1>
            <p>You have a balance of <?= $user->get_balance() ?>&euro;.</p>

            <div class="flex flex-col gap-y-4 w-full mt-4">
                <? foreach ($items as $item) { ?>
                    <div class="flex rounded-lg shadow-lg bg-white/5 border border-white/20 px-4 py-2 justify-between">
                        <div>
                            <p class="text-lg"><?= $item->get_item_name() ?></p>
                            <p class="text-sm opacity-75">
                                <?= $item->get_price() ?>&euro;
                                (<?= $item->get_availability() ?> available)
                            </p>
                        </div>
                        <? if (intval($item->get_availability()) > 0) { ?>
                            <button onclick='document.location="/api/apply.php?req=add&item=<?= $item->get_item_name() ?>&qty=1"'
                                value='Add to cart' class="text-center py-1 my-auto px-4 bg-madrhacks rounded-lg shadow-lg">
                                Add to cart
                            </button>
                        <? } ?>
                    </div>
                <? } ?>
            </div>
        </div>
    <?php } ?>
</body>

</html>