<?php
include_once("utils/common.php");
?>
<html>

<head>
    <title>Register page</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        madrhacks: "#00755c",
                    }
                }
            }
        }
    </script>
</head>

<body class="flex items-center justify-center">
    <? if (logged_in()) { ?>
        <div class="rounded-lg py-6 px-10 bg-white/10 shadow-lg max-w-xl w-full">
            <h1 class="text-2xl font-bold">Error</h1>
            <p>You are already logged as <b><?= logged_user() ?></b>.</p>
        </div>
    <? } else { ?>
        <form class="rounded-lg py-6 px-10 bg-white/10 shadow-lg max-w-xl w-full" action="/api/register.php" method="POST">
            <h1 class="text-2xl font-bold">Register</h1>
            <p>Already have an account? <a href="/login.php" class="font-medium">Login now!</a></p>

            <div class="flex flex-col gap-y-4 w-full mt-4">
                <input type="text" name="username" placeholder="Username"
                    class="placeholder:text-white/50 py-2 px-4 flex-grow bg-white/5 border border-white/20 rounded-lg shadow-lg" />
                <input type="password" name="password" placeholder="Password"
                    class="placeholder:text-white/50 py-2 px-4 flex-grow bg-white/5 border border-white/20 rounded-lg shadow-lg" />
                <input type="submit" name="submit" class="text-center py-2 px-4 flex-grow bg-madrhacks rounded-lg shadow-lg"
                    value="Submit" />
            </div>
        </form>
    <? } ?>
</body>

</html>