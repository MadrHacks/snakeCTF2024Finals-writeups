<?php
    include_once("../utils/common.php");
    
    if(isset($_POST["username"]) && isset($_POST["password"])){
        $username = $_POST["username"];
        $user = new User($_POST["username"], $_POST["password"], 0);
        $res = insert_user($user);
        log_general("Registered user " . $username);
        header("Content-Type: application/json");
        if ($res){
            header("Location: /login.php");
            echo '{"message": "success"}';
        } else {
            header("Location: /register.php"); // Try again noob
            echo '{"message": "failure"}';
        }
    }