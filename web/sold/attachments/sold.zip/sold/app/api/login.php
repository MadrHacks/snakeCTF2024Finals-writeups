<?php
    include_once("../utils/common.php");

    if(isset($_POST["username"]) && isset($_POST["password"])){
        $username = $_POST["username"];
        $password = $_POST["password"];
        $users = query_users();
        if(!array_key_exists($username, $users) || !$users[$username]->safe_password_compare($password)){
            echo '{"message": "failure"}';
            exit(0);
        }
        
        $_SESSION["user"] = $username;
        log_user("login", $username);
        session_write_close();
        header("Location: /index.php");
        header("Content-Type: application/json");
        echo $users[$username]->print(true);
    }