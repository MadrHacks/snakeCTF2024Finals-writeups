<?php
    include_once("../utils/common.php");
    header("Content-Type: application/json");
    if(!logged_in()){
        echo '{"message": "Log in to access the website!"}';
        exit(0);
    }

    if(isset($_REQUEST["req"]) && $_REQUEST["req"] == "add") {
        if(!isset($_REQUEST["item"]) || !isset($_REQUEST["qty"])){
            echo '{"message": "Invalid request"}';
            exit(0);
        }
        $item = $_REQUEST["item"];
        $quantity = $_REQUEST["qty"];
        
        $cart = get_cart();
        $cart->add_object($item, $quantity);
        set_cart($cart);
        log_user("Added " . $item . "(" . $quantity . ")" . " to the cart", logged_user());
        header("Location: /mycart.php");
        echo $cart->print(true);
        exit(0);
    }

    if(isset($_REQUEST["req"]) && $_REQUEST["req"] == "remove") {
        if(!isset($_REQUEST["item"])){
            echo '{"message": "Invalid request"}';
            exit(0);
        }
        $item = $_REQUEST["item"];
        
        $cart = get_cart();
        $cart->remove_object($item);
        log_user("Removed " . $item . " from the cart", logged_user());
        set_cart($cart);
        header("Location: /mycart.php");
        echo $cart->print(true);
        exit(0);
    }

    if(isset($_REQUEST["req"]) && $_REQUEST["req"] == "discount"){
        if(!isset($_REQUEST["action"]) || ($_REQUEST["action"] == 'add' && !isset($_REQUEST["coupon"]))){
            echo '{"message": "Invalid request"}';
            exit(0);
        }
        $cart = get_cart();
        if($_REQUEST["action"] == 'add'){
            $coupon_code = $_REQUEST["coupon"];
            $coupon = query_coupon($coupon_code);
            if($coupon == false){
                log_user("Attempt to apply coupon " . $coupon_code, logged_user());
                echo '{"message": "Coupon not found!"}';
                exit(0);
            }
            $cart->add_coupon($coupon);
            set_cart($cart);
            log_user("Applied coupon " . $coupon_code, logged_user());
            header("Location: /mycart.php");
            echo $coupon->print(true);
            exit(0);
        }
        if($_REQUEST["action"] == 'remove'){
            $cart->remove_coupon();
            log_user("Removed coupon", logged_user());
            set_cart($cart);
            header("Location: /mycart.php");
            echo '{"message": "Success"}';
            exit(0);
        }
    }