<?php
include_once("user.php");
include_once("item.php");
include_once("db.php");
include_once("coupon.php");
include_once("cart.php");
include_once("logger.php");
session_start();

$general_logger = new Logger();

function log_general($what){
    global $general_logger;
    $general_logger->print($what);
}
function log_user($what, $user){
    global $general_logger;
    $general_logger->print($what, $user);
}
function logged_in(){
    return isset($_SESSION["user"]);
}
function logged_user(){
    return $_SESSION["user"];
}
function logout() {
    unset($_SESSION["user"]);
}
function get_cart(){
    return isset($_COOKIE["cart"])? unserialize($_COOKIE["cart"]) : new Cart();
}
function set_cart($cart){
    setcookie("cart",  serialize($cart), 0, "/");
    session_write_close();
}
function clear_coupon(){
    $cart = get_cart();
    $cart->remove_coupon();
    set_cart($cart);
}
function get_visitor()
{
    $key = ftok(__FILE__, 't');
    $id = shmop_open($key, "c", 0644, 4);
    $content = (int)shmop_read($id, 0, 4);
    $content += 1;
    $written = shmop_write($id, $content, 0);
    //shmop_close($id);
    return $content;
}