<?php
    class Coupon {
        private $code;
        private $amount;

        function __construct($code, $amount){
            $this->code = $code;
            $this->amount = $amount;
        }
        
        function get_code(){
            return $this->code;
        }

        function print($as_json) {
            if($as_json){
                return <<<json
                {
                    "code": "$this->code",
                    "amount": "$this->amount"
                }
                json;
            }
            return $this->code . "( " . $this->amount . "€ )";
        }
        
        function get_amount(){
            return $this->amount;
        }

        function apply($objects) {
            $result = array();
            $remaining = $this->amount;
            foreach ($objects as $item_name => $data){
                $item = query_item($item_name);
                $max_discount = $item->get_discountability();
                $total = $data["price"];
                if($max_discount > 0){
                    $applicable = $max_discount * $data["quantity"];
                    $final = max($total - $remaining, $total - $applicable);
                    $remaining = $remaining - ($total - $final);
                    $total = $final;
                }
                $result[$item_name] = [
                    "quantity" => $data["quantity"],
                    "price" => $total
                ];
            }
            return $result;
        }
        function __wakeup(){
            $coupon = query_coupon($this->code);
            if ($coupon == false || $coupon->amount != $this->amount)
                clear_coupon();
        }
    }
