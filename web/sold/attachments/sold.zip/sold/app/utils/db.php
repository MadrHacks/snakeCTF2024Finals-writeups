<?php
    $conn = pg_connect("host="     . getenv("BACKEND_ADDRESS") . 
                      " dbname="   . getenv("BACKEND_DB")      . 
                      " user="     . getenv("BACKEND_USER")    .
                      " password=" . getenv("BACKEND_PASSWORD"));
    
    function query_users() {
        global $conn;
        $result = pg_query($conn,
            "SELECT * FROM users");
        $users = array();
        while($row = pg_fetch_row($result)) {
            $users[$row[1]] = new User($row[1], $row[2], $row[3]);
        }
        return $users;
    }

    function query_user($username) {
        global $conn;
        $data = array(
            "username" => $username
        );
        $result = pg_select($conn, "users", $data);
        if ($result !== false && count($result) > 0){
            return new User($result[0]["username"], $result[0]["pw"], $result[0]["balance"]);
        }
        return false;
    }

    function insert_user($user) {
        global $conn;
        $data = array(
            "username" => $user->get_username(),
            "pw" => $user->get_password(),
            "balance" => $user->get_balance()
        );
        $result = pg_insert($conn, "users", $data);
        return $result;
    }

    function query_items() {
        global $conn;
        $result = pg_query($conn,
            "SELECT * FROM items");
        $items = array();
        while($row = pg_fetch_row($result)) {
            $items[$row[1]] = new Item($row[1], $row[2], $row[3], $row[4]);
        }
        return $items;
    }

    function query_item($item_name) {
        global $conn;
        $data = array(
            "itemname" => $item_name
        );
        $result = pg_select($conn, "items", $data);
        if ($result !== false && count($result) > 0){
            return new Item($result[0]["itemname"], $result[0]["price"], $result[0]["availabilility"], $result[0]["maxdiscount"]);
        }
        return false;
    }

    function query_coupon($coupon_name){
        global $conn;
        $data = array(
            "couponname" => $coupon_name
        );
        $result = pg_select($conn, "coupons", $data);
        if ($result !== false && count($result) > 0){
            return new Coupon($result[0]["couponname"], (float)$result[0]["discount"]);
        }
        return false;
    }