<?php
    class Item {
        private $item_name;
        private $price;
        private $availability;
        private $discountability;

        function __construct($name, $price, $availability, $discountability){
            $this->item_name = $name;
            $this->price = $price;
            $this->availability = $availability;
            $this->discountability = $discountability;
        }
        
        function get_item_name(){
            return $this->item_name;
        }

        function get_price(){
            return $this->price;
        }
        
        function print($as_json){
            if($as_json){
                return <<<json
                {
                    "name": "$this->item_name",
                    "price": $this->price
                }
                json;
            }
        }

        function get_availability() {
            return $this->availability;
        }
        
        function get_discountability(){
            return $this->discountability;
        }

        function __wakeup(){

        }
        public function __destruct() {

        }
    }
