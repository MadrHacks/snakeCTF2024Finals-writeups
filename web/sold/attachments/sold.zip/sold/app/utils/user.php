<?php
    class User {
        private $username;
        private $password;
        private $balance;

        function __construct($u, $p, $balance){
            $this->username = $u;
            $this->password = $p;
            $this->balance = $balance;
        }

        function get_username(){
            return $this->username;
        }
        function print($as_json){
            if($as_json){
                return <<<json
                    {
                        "username": "$this->username",
                        "balance": "$this->balance"
                }
                json;
            }
            return $this->username . "( " . $this->balance . "€ )";
        }
        
        function get_password(){
            return $this->password;
        }
        
        function safe_password_compare($password){
            return $this->password === $password;
        }
        
        function get_balance(){
            return $this->balance;
        }
    }