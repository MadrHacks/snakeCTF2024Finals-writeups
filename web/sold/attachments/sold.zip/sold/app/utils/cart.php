<?php
    class Cart {
        private $objects_quantity_map;
        private $coupon;

        function __construct(){
            $this->objects_quantity_map = array();
        }
        
        function print($as_json){
            if($as_json){
                $items = "";
                foreach ($items as $i => $item)
                    $items .= $item->print($as_json) . ($i == count($items) - 1? "" :  ",");
                return <<<json
                {
                    "objects":[
                        $items
                    ]
                }
                json;
            }
        }

        function add_object($item_name, $quantity) {
            $item = query_item($item_name);
            if ($quantity > $item->get_availability())
                return false;

            $this->objects_quantity_map[$item_name] = [
                "quantity" => $quantity, 
                "price" => $item->get_price() * $quantity
            ];
            return true;
        }

        function remove_object($item_name){
            if(array_key_exists($item_name, $this->objects_quantity_map))
                unset($this->objects_quantity_map[$item_name]);
        }
        
        function get_objects(){
            return $this->objects_quantity_map;
        }

        function compute_total() {
            $total = 0;
            foreach ($this->objects_quantity_map as $data){
                $total += $data["price"];
            }
            return $total;
        }

        function add_coupon($coupon){
            $this->coupon = $coupon;
            $this->objects_quantity_map = $this->coupon->apply($this->objects_quantity_map);
        }
        
        function remove_coupon(){
            $this->coupon = null;
            foreach($this->objects_quantity_map as $item_name => $data){
                $item = query_item($item_name);
                $quantity = $data["quantity"];
                $this->objects_quantity_map[$item_name] = [
                    "quantity" => $quantity, 
                    "price" => $item->get_price() * $quantity
                ];
            }
        }

        function has_coupon(){
            return $this->coupon != null;
        }
        
        function get_coupon(){
            return $this->coupon;
        }

        function __wakeup(){
            foreach ($this->objects_quantity_map as $item_name=>$data){
                $item = query_item($item_name);
                if($data["quantity"] > $item->get_availability())
                    unset($this->objects_quantity_map[$item_name]);
            }
        }
    }
