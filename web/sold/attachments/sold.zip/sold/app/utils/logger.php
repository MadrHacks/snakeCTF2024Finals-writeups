<?php
    class Logger {
        private $logger_function;
        
        function __construct(){
            $this->logger_function = "error_log";
        }
        
        function set_logger_function($fname){
            $this->logger_function = $fname;
        }

        function print($what, $username = ""){   
            ($this->logger_function)("@" . $username . "> " . $what . "\n");
        }
    }