from goppa_code import Goppa_code
from utils import random_permutation_matrix, random_singular_matrix
from galois import GF2
import numpy as np

class McEliece():

    def __init__(self, n:int, k:int, t:int, m:int):
        self.Code = Goppa_code(n, m, t)
        P = random_permutation_matrix(n)
        S = random_singular_matrix(k)

        self.n = n
        self.t = t
        self.P_inv = np.linalg.inv(P)
        self.S_inv = np.linalg.inv(S)
        self.pub_key = S @ self.Code.G @ P


    def gen_error(self) -> GF2:
        positions = np.random.choice(range(self.n), self.t, replace=False)
        err = GF2([1 if i in positions else 0 for i in range(self.n)])
        return err
    

    def encrypt(self, pt:list) -> GF2:
        pt = GF2(pt)
        err = self.gen_error()
        pt = pt @ self.pub_key
        return pt + err
    
    
    def decrypt(self, ct:list) -> tuple[GF2, int]:
        ct = GF2(ct) 
        ct = ct @ self.P_inv
        ct, err_count = self.Code.decode(ct)
        pt = ct @ self.S_inv        
        return pt, err_count