from mceliece import McEliece
from random import randint
from signal import alarm
import os

n, k, t, m = [256, 96, 20, 8]
cipher = McEliece(n,k,t,m)

FLAG = os.getenv("FLAG", "snakeCTF{fake_flag}")
TIMEOUT = os.getenv("TIMEOUT", 240)
token_bin = bin(randint(0, 2**k -1))[2:].zfill(k)
encrypted_token = cipher.encrypt([int(d) for d in token_bin])

request_limit = k + 3

WELCOMING_LINE = """Welcome back. We have learnt the lesson and this time we'll be more strict when correcting errors.
However, we still offer a free flag for anybody who can decrypt the secret token.\n"""
SUCCESS_LINE = 'Yep, seems good.'
FAILURE_LINE = 'Too many errors in your code.'
MENU = """1) Get public key.
2) Get encrypted token.
3) Test ciphertext.
4) Submit token.\n"""


def get_encrypted_token():  
    tmp = ''.join([str(d) for d in encrypted_token])
    print(f"Encrypted token: {hex(int(tmp, 2))[2:]}")


def get_public_key():
    print("Here comes the Public Key:")
    for row in cipher.pub_key:
        tmp = ''.join([str(d) for d in row])
        print(hex(int(tmp, 2))[2:])


def test_ciphertext():
    ct_hex = input("Ciphertext to test(in hex): ")
    ct = [int(d) for d in bin(int(ct_hex, 16))[2:].zfill(n)]
    
    pt, err_count = cipher.decrypt(ct)
 
    if ''.join([str(d) for d in pt]) == token_bin and err_count == (t-1): 
        print(SUCCESS_LINE)
    else:
        print(FAILURE_LINE)


def submit_token():    
    submitted_token = input("Submit the token(in hex): ")
    submitted_token_bin = [int(d) for d in bin(int(submitted_token, 16))[2:].zfill(k)]

    if ''.join([str(d) for d in submitted_token_bin]) == token_bin:
        print(f"That's right. You deserve a flag: {FLAG}")
    else:
        print("Wrong token. See ya.")


def handle():
    global request_limit
    print(WELCOMING_LINE)
    print(MENU)

    while request_limit > 0:
        try:
            option = int(input('\n> '))
            if option == 1:
                get_public_key()
            elif option == 2:
                get_encrypted_token()
            elif option == 3:
                test_ciphertext()              
            elif option == 4:
                request_limit = 1
                submit_token()
            else:
                print("We don't do that.")           
        except:
            print("Something went wrong.")
        finally:
            request_limit -=  1
                   

if __name__ == '__main__':
    alarm(TIMEOUT)
    handle()