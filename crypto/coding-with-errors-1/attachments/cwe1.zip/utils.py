from galois import Poly, GF2, egcd, GF
import numpy as np


def random_singular_matrix(n:int):
    M = GF2.Random((n,n))
    while np.linalg.det(M) == 0:
        M = GF2.Random((n,n))

    return M


def random_permutation_matrix(n:int):
    perm = np.random.permutation(range(n))
    rows = [[1 if j==perm[i] else 0 for j in range(n)] for i in range(n)]
    return GF2(rows)    


def split_poly(P:Poly) -> tuple[Poly, Poly]:
    coeffs = P.coeffs[::-1]
    A_coeffs = []
    B_coeffs = []
    
    for i in range(len(coeffs)):
        if i % 2 == 0:
            A_coeffs.append(np.sqrt(coeffs[i]))
        else:
            B_coeffs.append(np.sqrt(coeffs[i]))

    return Poly(A_coeffs[::-1], P.field), Poly(B_coeffs[::-1], P.field)


def sqrt_mod_poly(P:Poly, mod:Poly) -> Poly:
    mod_0, mod_1 = split_poly(mod)
    P_0, P_1 = split_poly(P)
    sqrt_identity = mod_0 * inverse_mod_poly(mod_1, mod)

    return (P_0 + sqrt_identity * P_1) % mod


def inverse_mod_poly(P:Poly, mod:Poly) -> Poly:
    return egcd(P, mod)[1]


def egcd_alt(P:Poly, goppa_poly:Poly) -> tuple[Poly, Poly, Poly]:
    t = goppa_poly.degree
    x1, x2 = Poly.Zero(goppa_poly.field), Poly.One(goppa_poly.field)
    y1, y2 = Poly.One(goppa_poly.field), Poly.Zero(goppa_poly.field)
    a = P
    b = goppa_poly

    while not a.degree <= t//2 or not x2.degree <= (t-1)//2:
        q, r = divmod(a, b)
        x = x2 - q * x1
        y = y2 - q * y1
        a, b, x2, x1, y2, y1 = b, r, x1, x, y1, Poly.One(goppa_poly.field)

    return (x2, y2, a)