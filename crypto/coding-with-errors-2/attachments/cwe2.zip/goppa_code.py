from galois import GF, GF2, irreducible_poly, Poly
import numpy as np
from utils import inverse_mod_poly, sqrt_mod_poly, egcd_alt

class Goppa_code():

    def __init__(self, n:int, m:int, t:int):
        GF2m = GF(2**m)

        g = irreducible_poly(n, t, method='random')          
        support = list(GF2m.elements)        
        g_coeffs = g.coeffs
        
        T_low = GF2m([[g_coeffs[i-j] if i >= j else 0 for j in range(t)] for i in range(t)])
        V = GF2m([[support[j]**i for j in range(n)] for i in range(t)])
        D = GF2m([[g(support[j])**(-1) if j==i else 0 for j in range(n)] for i in range(n)])
        H = T_low @ V @ D
        
        H_bin = GF2(np.concatenate([np.column_stack([e.vector() for e in row]) for row in H]))
        G = H_bin.null_space()
        
        self.G = G
        self.H = H
        self.g = g
        self.support = support
        self.GF2m = GF2m


    def correct_errors(self, syndrome:Poly, w:GF2) -> tuple[GF2, int]:
        if (T:= inverse_mod_poly(syndrome, self.g)).degree == 1 and T.coeffs[0] == 1:
            sigma_poly = T
        else:
            T += Poly.Identity(self.GF2m)
            R = sqrt_mod_poly(T, self.g)
            beta, _, alpha = egcd_alt(R, self.g)
            sigma_poly = alpha**2 + Poly.Identity(self.GF2m) * beta**2
        
        error_count = 0
        for i in range(len(w)):
            if sigma_poly(self.support[i]) == Poly.Zero(self.GF2m):
                w[i] += GF2(1) 
                error_count += 1

        return (w, error_count)
 

    def decode(self, w:GF2) -> tuple[GF2, int]:    
        syndrome = Poly.Zero(self.GF2m)
        for i in range(len(w)):
            if w[i] == 0:
                continue           
            tmp = Poly([1, -self.support[i]], self.GF2m)
            syndrome += inverse_mod_poly(tmp, self.g)
        
        if syndrome != Poly.Zero(self.GF2m):            
            w_correct, error_count = self.correct_errors(syndrome, w)
        else:           
            w_correct = w
            error_count = 0
        
        system_to_solve = GF2(np.append(self.G.T, w_correct.reshape(len(w_correct), 1), axis=1))
        reduced_system = system_to_solve.row_reduce(self.G.shape[0])
        m = reduced_system[:self.G.shape[0]].T[-1] 

        return m, error_count